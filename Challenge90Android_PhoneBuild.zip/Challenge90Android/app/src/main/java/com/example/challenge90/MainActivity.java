package com.example.challenge90;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.content.SharedPreferences;
import android.text.InputType;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int DAYS = 90;
    private SharedPreferences prefs;
    private LinearLayout rowsContainer;
    private TextView progressText, percentText, totalText, nextProfitText;
    private EditText startProfitInput, percentInput;
    private Button autoPercentButton;
    private boolean manualPercent = false;
    private final boolean[] checked = new boolean[DAYS];
    private final String[] dates = new String[DAYS];
    private final CheckBox[] checkBoxes = new CheckBox[DAYS];
    private final Button[] dateButtons = new Button[DAYS];
    private int teal = Color.rgb(23, 107, 135);
    private int ink = Color.rgb(31, 41, 55);
    private int muted = Color.rgb(107, 114, 128);
    private int line = Color.rgb(224, 231, 238);

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("challenge90_data", MODE_PRIVATE);
        for (int i = 0; i < DAYS; i++) {
            checked[i] = prefs.getBoolean("done_" + i, false);
            dates[i] = prefs.getString("date_" + i, "");
        }
        manualPercent = prefs.getBoolean("manual_percent_enabled", false);
        buildScreen();
        refreshStats();
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable rounded(int color, int strokeColor) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), strokeColor);
        return bg;
    }

    private TextView text(String value, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return t;
    }

    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return l;
    }

    private LinearLayout horizontal() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return l;
    }

    private void addSpace(LinearLayout parent, int heightDp) {
        View v = new View(this);
        parent.addView(v, new LinearLayout.LayoutParams(1, dp(heightDp)));
    }

    private void buildScreen() {
        ScrollView outer = new ScrollView(this);
        outer.setFillViewport(true);
        outer.setBackgroundColor(Color.rgb(247, 249, 252));
        LinearLayout page = vertical();
        page.setPadding(dp(16), dp(18), dp(16), dp(28));
        outer.addView(page);
        setContentView(outer);

        TextView title = text("چالش ۹۰ روزه", 25, ink, true);
        title.setGravity(Gravity.CENTER);
        page.addView(title, new LinearLayout.LayoutParams(-1, dp(48)));
        TextView subtitle = text("هر روز یک قدم به هدف نزدیک‌تر شو", 14, muted, false);
        subtitle.setGravity(Gravity.CENTER);
        page.addView(subtitle, new LinearLayout.LayoutParams(-1, dp(28)));
        addSpace(page, 12);

        LinearLayout stats = horizontal();
        page.addView(stats, new LinearLayout.LayoutParams(-1, dp(105)));
        LinearLayout progressCard = statCard("پیشرفت چالش", "۰ از ۹۰ روز");
        progressText = (TextView) progressCard.getChildAt(1);
        percentText = (TextView) progressCard.getChildAt(2);
        stats.addView(progressCard, new LinearLayout.LayoutParams(0, -1, 1));
        View gap = new View(this);
        stats.addView(gap, new LinearLayout.LayoutParams(dp(10), 1));
        LinearLayout totalCard = statCard("سود تجمعی روز ۹۰", "۴۰۹۵");
        totalText = (TextView) totalCard.getChildAt(1);
        nextProfitText = text("سود روز بعدی: ۱", 12, muted, false);
        totalCard.addView(nextProfitText);
        stats.addView(totalCard, new LinearLayout.LayoutParams(0, -1, 1));
        addSpace(page, 14);

        LinearLayout settings = vertical();
        settings.setPadding(dp(14), dp(12), dp(14), dp(12));
        settings.setBackground(rounded(Color.WHITE, line));
        page.addView(settings, new LinearLayout.LayoutParams(-1, -2));
        settings.addView(text("تنظیم چالش", 17, ink, true));
        addSpace(settings, 6);
        settings.addView(text("درصد پیشرفت (قابل تغییر دستی)", 13, muted, false));
        percentInput = new EditText(this);
        percentInput.setSingleLine(true);
        percentInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        percentInput.setText(prefs.getString("manual_percent", "0"));
        percentInput.setTextSize(16);
        percentInput.setPadding(dp(10), 0, dp(10), 0);
        percentInput.setBackground(rounded(Color.rgb(250, 251, 253), line));
        settings.addView(percentInput, new LinearLayout.LayoutParams(-1, dp(46)));
        Button setPercent = button("اعمال درصد دلخواه");
        settings.addView(setPercent, new LinearLayout.LayoutParams(-1, dp(42)));
        setPercent.setOnClickListener(v -> {
            try {
                int pct = Integer.parseInt(percentInput.getText().toString().trim());
                if (pct < 0 || pct > 100) throw new NumberFormatException();
                manualPercent = true;
                prefs.edit().putInt("manual_percent", pct).putBoolean("manual_percent_enabled", true).apply();
                refreshStats();
                Toast.makeText(this, "درصد پیشرفت تنظیم شد", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "درصد باید عددی بین صفر تا ۱۰۰ باشد", Toast.LENGTH_SHORT).show();
            }
        });
        autoPercentButton = button("محاسبه خودکار درصد بر اساس تیک‌ها");
        settings.addView(autoPercentButton, new LinearLayout.LayoutParams(-1, dp(42)));
        autoPercentButton.setOnClickListener(v -> {
            manualPercent = false;
            prefs.edit().putBoolean("manual_percent_enabled", false).apply();
            refreshStats();
            Toast.makeText(this, "درصد به حالت خودکار برگشت", Toast.LENGTH_SHORT).show();
        });
        addSpace(settings, 8);
        settings.addView(text("سود روز اول (قابل تغییر)", 13, muted, false));
        startProfitInput = new EditText(this);
        startProfitInput.setSingleLine(true);
        startProfitInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        startProfitInput.setText(prefs.getString("start_profit", "1"));
        startProfitInput.setTextSize(16);
        startProfitInput.setPadding(dp(10), 0, dp(10), 0);
        startProfitInput.setBackground(rounded(Color.rgb(250, 251, 253), line));
        settings.addView(startProfitInput, new LinearLayout.LayoutParams(-1, dp(46)));
        startProfitInput.setOnFocusChangeListener((v, hasFocus) -> { if (!hasFocus) refreshStats(); });
        Button apply = button("اعمال مقدار سود");
        settings.addView(apply, new LinearLayout.LayoutParams(-1, dp(44)));
        apply.setOnClickListener(v -> {
            String value = startProfitInput.getText().toString().trim();
            try {
                double n = Double.parseDouble(value);
                if (n < 0) throw new NumberFormatException();
                prefs.edit().putString("start_profit", value).apply();
                refreshStats();
                renderRows();
                Toast.makeText(this, "مقدار سود به‌روزرسانی شد", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "یک عدد صفر یا بزرگ‌تر وارد کن", Toast.LENGTH_SHORT).show();
            }
        });
        addSpace(page, 14);

        LinearLayout actions = horizontal();
        page.addView(actions, new LinearLayout.LayoutParams(-1, dp(46)));
        Button next = button("تیک روز بعدی");
        actions.addView(next, new LinearLayout.LayoutParams(0, -1, 1));
        next.setOnClickListener(v -> {
            int index = -1;
            for (int i = 0; i < DAYS; i++) if (!checked[i]) { index = i; break; }
            if (index == -1) {
                Toast.makeText(this, "تبریک! هر ۹۰ روز تکمیل شده است.", Toast.LENGTH_LONG).show();
            } else {
                checked[index] = true;
                if (dates[index] == null || dates[index].isEmpty()) dates[index] = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
                prefs.edit().putBoolean("done_" + index, true).putString("date_" + index, dates[index]).apply();
                refreshStats();
                renderRows();
                Toast.makeText(this, "روز " + (index + 1) + " تکمیل شد", Toast.LENGTH_SHORT).show();
            }
        });
        View actionGap = new View(this);
        actions.addView(actionGap, new LinearLayout.LayoutParams(dp(8), 1));
        Button reset = button("شروع مجدد");
        actions.addView(reset, new LinearLayout.LayoutParams(0, -1, 1));
        reset.setOnClickListener(v -> new android.app.AlertDialog.Builder(this)
            .setTitle("شروع مجدد چالش")
            .setMessage("همه تیک‌ها و تاریخ‌ها پاک شوند؟")
            .setNegativeButton("لغو", (d, w) -> {})
            .setPositiveButton("پاک کردن", (d, w) -> {
                SharedPreferences.Editor editor = prefs.edit();
                for (int i = 0; i < DAYS; i++) { checked[i] = false; dates[i] = ""; editor.remove("done_" + i).remove("date_" + i); }
                manualPercent = false;
                editor.remove("manual_percent").putBoolean("manual_percent_enabled", false).apply();
                refreshStats(); renderRows();
            }).show());
        addSpace(page, 16);

        TextView tableTitle = text("برنامه روزانه", 19, ink, true);
        page.addView(tableTitle, new LinearLayout.LayoutParams(-1, dp(36)));
        TextView explanation = text("سود روزانه هر روز یک واحد بیشتر می‌شود؛ سود تجمعی مجموع سود روزهاست.", 12, muted, false);
        page.addView(explanation, new LinearLayout.LayoutParams(-1, dp(40)));

        LinearLayout header = horizontal();
        header.setPadding(dp(8), dp(8), dp(8), dp(8));
        header.setBackground(rounded(Color.rgb(230, 240, 245), line));
        String[] labels = {"روز", "سود روز", "سود تجمعی", "✓", "تاریخ"};
        float[] weights = {0.65f, 1.0f, 1.15f, 0.55f, 1.4f};
        for (int i = 0; i < labels.length; i++) {
            TextView t = text(labels[i], 11, teal, true);
            t.setGravity(Gravity.CENTER);
            header.addView(t, new LinearLayout.LayoutParams(0, dp(30), weights[i]));
        }
        page.addView(header, new LinearLayout.LayoutParams(-1, -2));

        rowsContainer = vertical();
        page.addView(rowsContainer, new LinearLayout.LayoutParams(-1, -2));
        renderRows();
    }

    private LinearLayout statCard(String label, String value) {
        LinearLayout card = vertical();
        card.setPadding(dp(10), dp(10), dp(10), dp(10));
        card.setBackground(rounded(Color.WHITE, line));
        card.addView(text(label, 12, muted, false));
        card.addView(text(value, 19, ink, true));
        card.addView(text("", 12, muted, false));
        return card;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackground(rounded(teal, teal));
        return b;
    }

    private double startingProfit() {
        try { return Math.max(0, Double.parseDouble(startProfitInput.getText().toString().trim())); }
        catch (Exception e) { return 1; }
    }

    private String fmt(double value) {
        return NumberFormat.getNumberInstance(new Locale("fa", "IR")).format(value);
    }

    private void refreshStats() {
        double start = startingProfit();
        int done = 0;
        for (boolean b : checked) if (b) done++;
        double lastDaily = start + 89;
        double sum = (90.0 * (2 * start + 89)) / 2.0;
        if (progressText != null) progressText.setText(fmt(done) + " از ۹۰ روز");
        int autoPct = (int)Math.round(done * 100.0 / 90);
        int pct = manualPercent ? prefs.getInt("manual_percent", 0) : autoPct;
        if (percentText != null) percentText.setText(fmt(pct) + "٪" + (manualPercent ? " (دستی)" : " (خودکار)"));
        if (percentInput != null) percentInput.setText(String.valueOf(pct));
        if (totalText != null) totalText.setText(fmt(sum));
        if (nextProfitText != null) {
            int next = 0;
            while (next < DAYS && checked[next]) next++;
            nextProfitText.setText("سود روز بعدی: " + fmt(start + Math.min(next, 89)));
        }
    }

    private void renderRows() {
        if (rowsContainer == null) return;
        rowsContainer.removeAllViews();
        double start = startingProfit();
        double cumulative = 0;
        for (int i = 0; i < DAYS; i++) {
            double daily = start + i;
            cumulative += daily;
            LinearLayout row = horizontal();
            row.setPadding(dp(5), dp(3), dp(5), dp(3));
            row.setMinimumHeight(dp(48));
            if (i % 2 == 0) row.setBackgroundColor(Color.rgb(250, 251, 253));
            else row.setBackgroundColor(Color.WHITE);
            TextView day = text(String.valueOf(i + 1), 12, checked[i] ? teal : ink, checked[i]);
            day.setGravity(Gravity.CENTER);
            row.addView(day, new LinearLayout.LayoutParams(0, dp(42), 0.65f));
            TextView dailyText = text(fmt(daily), 12, ink, false);
            dailyText.setGravity(Gravity.CENTER);
            row.addView(dailyText, new LinearLayout.LayoutParams(0, dp(42), 1.0f));
            TextView cumText = text(fmt(cumulative), 12, ink, true);
            cumText.setGravity(Gravity.CENTER);
            row.addView(cumText, new LinearLayout.LayoutParams(0, dp(42), 1.15f));
            CheckBox check = new CheckBox(this);
            check.setButtonTintList(android.content.res.ColorStateList.valueOf(teal));
            check.setChecked(checked[i]);
            check.setPadding(0, 0, 0, 0);
            check.setGravity(Gravity.CENTER);
            final int index = i;
            check.setOnCheckedChangeListener((buttonView, isChecked) -> {
                checked[index] = isChecked;
                if (isChecked && (dates[index] == null || dates[index].isEmpty()))
                    dates[index] = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
                prefs.edit().putBoolean("done_" + index, isChecked).putString("date_" + index, dates[index] == null ? "" : dates[index]).apply();
                refreshStats();
                // Update the date label without rebuilding this row and losing scroll position.
                if (dateButtons[index] != null) dateButtons[index].setText(dates[index].isEmpty() ? "انتخاب" : dates[index]);
                day.setTextColor(isChecked ? teal : ink);
                day.setTypeface(Typeface.DEFAULT, isChecked ? Typeface.BOLD : Typeface.NORMAL);
            });
            row.addView(check, new LinearLayout.LayoutParams(0, dp(42), 0.55f));
            Button dateButton = new Button(this);
            dateButton.setTextSize(9);
            dateButton.setAllCaps(false);
            dateButton.setMinWidth(0);
            dateButton.setPadding(dp(1), 0, dp(1), 0);
            dateButton.setText(dates[i] == null || dates[i].isEmpty() ? "انتخاب" : dates[i]);
            dateButton.setTextColor(teal);
            dateButton.setBackground(rounded(Color.WHITE, line));
            dateButton.setOnClickListener(v -> {
                Calendar cal = Calendar.getInstance();
                if (dates[index] != null && dates[index].matches("\\d{4}-\\d{2}-\\d{2}")) {
                    try {
                        String[] parts = dates[index].split("-");
                        cal.set(Integer.parseInt(parts[0]), Integer.parseInt(parts[1]) - 1, Integer.parseInt(parts[2]));
                    } catch (Exception ignored) {}
                }
                new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
                    dates[index] = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, dayOfMonth);
                    prefs.edit().putString("date_" + index, dates[index]).apply();
                    dateButton.setText(dates[index]);
                }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show();
            });
            dateButtons[i] = dateButton;
            row.addView(dateButton, new LinearLayout.LayoutParams(0, dp(38), 1.4f));
            rowsContainer.addView(row);
            View divider = new View(this);
            divider.setBackgroundColor(line);
            rowsContainer.addView(divider, new LinearLayout.LayoutParams(-1, dp(1)));
            checkBoxes[i] = check;
        }
    }
}
